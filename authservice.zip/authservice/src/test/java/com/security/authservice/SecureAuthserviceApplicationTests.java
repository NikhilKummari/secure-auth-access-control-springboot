package com.security.authservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureAuthserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
